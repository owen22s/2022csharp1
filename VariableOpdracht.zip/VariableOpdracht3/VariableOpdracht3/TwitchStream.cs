﻿namespace VariableOpdracht3
{
    //vul de ??? in
    internal class TwitchStream
    {
        private string tag;

        internal TwitchStream(string tag)
        {
            this.tag = tag;
        }
        internal string GetTag()
        {
            return tag;
        }

        internal void SetTag(???)//maak hier een variable: type: string, name: tag
        {
            this.tag = tag;
        }
    }
}