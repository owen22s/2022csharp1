using System;

namespace VariableOpdracht4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //hello world is een vaste string

            //maak een variable die constant is
            //vergeet het type niet!

            ???? helloWorldConstante = "Hello world!";
            Console.WriteLine(????);

        }
    }
}