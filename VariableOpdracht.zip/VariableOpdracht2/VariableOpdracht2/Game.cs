﻿using System;

namespace VariableOpdracht2
{
    internal class Game
    {
        internal string name;

        internal Game(string name)//constructor
        {
            this.name = name;
        }
    }
}