﻿using System;

namespace ArrayOpdracht4
{
    internal class Enemy
    {
        internal int id;

        internal Enemy(int id)
        {
            this.id = id;
        }
    }
}