﻿using System;

namespace ArrayOpdracht3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            string[] nameparts = new string[] { "mar", "chu" , "io", "li",  "pika", "nk" };


            Console.WriteLine(nameparts[0] + nameparts[2]);

            //maak nu de volgende namen en schrijf het naar de console:

            //link

            //pikachu

            //linkio

            //chumar
        }
    }
}