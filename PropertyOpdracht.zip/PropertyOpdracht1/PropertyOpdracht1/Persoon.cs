﻿namespace PropertyOpdracht1
{
    internal class Persoon
    {
        public Persoon()
        {
        }

        public string Naam { get; internal set; }
        public int Leeftijd { get; internal set; }
    }
}