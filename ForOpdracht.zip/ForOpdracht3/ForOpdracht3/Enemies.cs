﻿namespace ForOpdracht3
{
    class Enemies
    {
        internal bool defeated;
        internal string name;
    }
}