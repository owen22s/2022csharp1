﻿using System;

namespace ForOpdracht1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] straten = new string[] { "contactweg", "dintelstraat" };

            //type nu hieronder for, dan druk je de TAB toets in, achter i < zet je straten.Length


            //in de for loop schrijf je nu een Console.WriteLine() met tussen de haakjes straten[i]

            //run het programma (groene play knop) wat gebeurt er?
           





        }
    }
}