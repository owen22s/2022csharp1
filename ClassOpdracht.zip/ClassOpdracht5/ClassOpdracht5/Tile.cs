﻿using System;

namespace ClassOpdracht5
{
    class Tile
    {
        internal int x, y;
        internal char graphic;
        internal ConsoleColor color = ConsoleColor.Green;

        internal Tile(int x, int y,char graphic)
        {
			//vergeet this niet te gebruiken!
            //geef hier de waarde van x aan class variable x
            ???
            //geef hier de waarde van y aan class variable y
            ???
            //geef hier de waarde van graphic aan class variable graphic 
            ???
        }
    }
}

