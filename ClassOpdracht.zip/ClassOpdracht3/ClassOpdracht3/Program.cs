using System;

namespace ClassOpdracht3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            //we gaan de static ontsnappen

            //1) maak een nieuwe class aan die je GameEngine noemt       (gebruik rechter muis op het project ClassOpdracht3->add->new class

            //2) maak hier een nieuwe instance aan van GameEngine

            //3)  plak deze function hieronder in GameEngine:
           
            /*
                    internal void RunGameLoop()
                    { 
                        while(true)
                        {
                            Console.WriteLine("loop 1 time!");
                            System.Threading.Thread.Sleep(1000);//usings komen later dus even met System.Threading ervoor ^^
                        }
                    }
             */

            //4) roep hier de rungameloop aan 
           


        }
    }
}